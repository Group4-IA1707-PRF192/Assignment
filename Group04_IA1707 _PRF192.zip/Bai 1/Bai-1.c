#include<stdio.h>
#include<stdlib.h>
double giaiThua (int x){
	int i;
	double giaithua = 1;
	for (i =1; i<=x;i++){
		giaithua = giaithua*i;
	}
	return giaithua;
}
int main()
{
	FILE *in = fopen("TOHOP.INP","r");
	FILE *out = fopen("TOHOP.OUT","w");
	int n,i,  k;
	double toHop = 0;
	fscanf(in,"%d",&n);
	fscanf(in,"%d",&k);
	toHop = giaiThua(n) / (giaiThua(k)*giaiThua(n-k));
	fprintf(out,"To hop chap %d cua %d la: %.lf\n", k, n, toHop);
	for ( i =1; i<3;i++){
		fscanf(in,"%d",&n);
		fscanf(in,"%d",&k);
		toHop = giaiThua(n) / (giaiThua(k)*giaiThua(n-k));
		fprintf(out,"To hop chap %d cua %d la: %.lf\n", k, n, toHop);
		printf("To hop chap %d cua %d la: %.lf\n", k, n, toHop);
	}
	fclose(in);
	fclose(out);
	return 0;
}
